// ==UserScript==
// @name         AC
// @namespace    AC Auto
// @icon         http://acm.hdu.edu.cn/favicon.ico
// @version      0.1
// @description  AC Auto Push
// @author       My
// @match        http://acm.hdu.edu.cn/submit.php
// @run-at       document-end
// @grant        none
// ==/UserScript==


var run = function() {
	var id = "0000";
	var code = "test";

	document.querySelector("[name='problemid']").value = id;
	document.querySelector('.code').value = code;
	//document.querySelector('.button40').click();
};
run();