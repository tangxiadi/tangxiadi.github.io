// ==UserScript==
// @name         Pixiv manga loader lite
// @namespace    https://cryptogeek.ninja/
// @icon         http://www.pixiv.net/favicon.ico
// @version      0.4
// @description  Instantly displays all thumbnails when in manga mode and makes them clickable to show full size images.
// @match        http://www.pixiv.net/member_illust.php?mode=manga&illust_id=*
// @grant        none
// ==/UserScript==

//get number of images
t = pixiv.context.images.length;

//replace content with loader and remove broken buttons
if ( document.getElementsByClassName('manga')[0] ) {
	document.getElementsByClassName('manga')[0].innerHTML = '<div class="loader" style="text-align:center;"></div>';
    document.getElementsByClassName('page-menu')[0].innerHTML = '';
}
else {   
    window.stop();
    document.getElementsByClassName('images')[0].innerHTML = '<div class="loader" style="text-align:center;"></div>';
    document.getElementsByClassName('images')[0].removeAttribute("class");
    document.getElementsByClassName('item toggle-size')[0].innerHTML = '';
    document.getElementsByClassName('item left')[0].innerHTML = '';
    document.getElementsByClassName('item right _disabled')[0].innerHTML = '';
    document.getElementsByClassName('item position')[0].innerHTML = '';
    document.getElementsByClassName('item position')[0].innerHTML += '<a href="' + document.URL.replace("manga","medium") + '">Return</a>';
}

//load all thumbnails in loader
for (i = 0; i < t; i++) { 
    document.getElementsByClassName('loader')[0].innerHTML += '<a target="_blank" href="' + pixiv.context.images[i] + '"><img src="' + pixiv.context.thumbnailImages[i] + '" ></a>';
}